/* Fluxel custom API helper. Set window.FLUXEL_API_BASE before this file loads. */
(function () {
  if (window.FluxelAPI) return;
  const base = String(window.FLUXEL_API_BASE || "").replace(/\/+$/, "");
  const tokenKey = "fluxelApiToken";
  async function request(path, options) {
    if (!base) throw new Error("Fluxel API is not configured yet. Set window.FLUXEL_API_BASE.");
    const token = localStorage.getItem(tokenKey);
    const headers = Object.assign({ "Content-Type": "application/json" }, (options && options.headers) || {});
    if (token) headers.Authorization = "Bearer " + token;
    const response = await fetch(base + path, Object.assign({}, options || {}, { headers }));
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || "Fluxel API request failed.");
    return body;
  }
  window.FluxelAPI = {
    register: async (username, email, password) => {
      const result = await request("/api/auth/register", { method: "POST", body: JSON.stringify({ username, email, password }) });
      localStorage.setItem(tokenKey, result.token); return result.user;
    },
    login: async (email, password) => {
      const result = await request("/api/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
      localStorage.setItem(tokenKey, result.token); return result.user;
    },
    logout: () => localStorage.removeItem(tokenKey),
    me: () => request("/api/me"),
    updateProfile: (profile) => request("/api/me/profile", { method: "PATCH", body: JSON.stringify(profile) }),
    save: (key, data) => request("/api/saves/" + encodeURIComponent(key), { method: "PUT", body: JSON.stringify({ data }) }),
    getSave: (key) => request("/api/saves/" + encodeURIComponent(key)),
    getSaves: () => request("/api/saves"),
    servers: () => request("/api/servers"),
    createServer: (gameId, maxPlayers) => request("/api/servers", { method: "POST", body: JSON.stringify({ gameId, maxPlayers }) }),
    joinServer: (roomCode) => request("/api/servers/join", { method: "POST", body: JSON.stringify({ roomCode }) })
  };
})();