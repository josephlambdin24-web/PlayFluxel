# Fluxel Custom Backend (no Supabase)

This is a separate Node.js API with a SQLite database. It does **not** use Supabase, Firebase, or Netlify Functions.

## What it includes
- Email + password registration and login (passwords are bcrypt-hashed).
- Signed bearer tokens.
- Player profiles and avatar JSON.
- Private per-user save data.
- A starter game-server/room-code registry.
- CORS allow-list, basic security headers, and auth rate limiting.

## Important hosting note
Netlify Drop hosts static files; it does not run this persistent Node.js server. Keep your current Fluxel Netlify site as-is and host this API separately on a Node.js host that supports persistent storage, such as a small VPS or a service with a persistent disk. The SQLite database must live on persistent storage. Do not use ephemeral filesystem storage for production player data.

## Run locally
1. Install Node.js 20 or newer.
2. In this `backend` folder, copy `.env.example` to `.env`.
3. Set `JWT_SECRET` to a long random secret (at least 32 characters).
4. Set `CORS_ORIGINS` to your exact Fluxel website origin, e.g. `https://your-site.netlify.app` (no trailing slash). Include localhost only if needed for development.
5. Run `npm install`, then `npm start`.
6. Open `http://localhost:3000/api/health`; it should return `{"ok":true,"service":"Fluxel API","database":"connected"}`.

## API
- `POST /api/auth/register` `{ "username": "...", "email": "...", "password": "..." }`
- `POST /api/auth/login` `{ "email": "...", "password": "..." }`
- `GET /api/me` (Bearer token)
- `PATCH /api/me/profile` `{ "displayName": "...", "avatar": {} }` (Bearer token)
- `PUT /api/saves/:key` `{ "data": {} }` (Bearer token)
- `GET /api/saves` (Bearer token)
- `GET /api/saves/:key` (Bearer token)
- `GET /api/servers`
- `POST /api/servers` `{ "gameId": "summit-sprint", "maxPlayers": 12 }` (Bearer token)
- `POST /api/servers/join` `{ "roomCode": "ABC123" }` (Bearer token)

All authenticated requests use `Authorization: Bearer YOUR_TOKEN`.

## Frontend integration
`public/fluxel-api-client.js` is a small browser helper. After the API is hosted, set `window.FLUXEL_API_BASE` to its base URL and load the helper on the pages you want to connect. This is an integration layer only; it does not automatically wire every existing Fluxel UI button. Existing UI controls must be connected to the matching API calls.

## Production cautions
- SQLite is suitable for an initial small project, but the host must provide persistent disk and backups. For multi-instance scaling, move to PostgreSQL or another managed database.
- Use HTTPS in production.
- Do not put JWT_SECRET or any server-only secrets in HTML or public JavaScript.
- The room registry is a starter directory, not a real-time multiplayer transport. Actual live multiplayer needs WebSockets and server/game-process coordination.
- This starter is not yet integrated into Fluxel's existing account UI or all game systems.
