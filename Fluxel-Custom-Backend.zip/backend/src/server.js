require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32 || JWT_SECRET === "replace-this-with-a-long-random-secret") {
  console.error("Set JWT_SECRET in backend/.env to a unique random secret of at least 32 characters.");
  process.exit(1);
}

app.disable("x-powered-by");
app.use(helmet());
const origins = (process.env.CORS_ORIGINS || "http://localhost:3000").split(",").map(x => x.trim()).filter(Boolean);
app.use(cors({ origin(origin, cb) {
  if (!origin || origins.includes(origin)) return cb(null, true);
  return cb(new Error("Origin not allowed by CORS"));
}}));
app.use(express.json({ limit: "100kb" }));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const dbPath = path.resolve(process.env.DATABASE_PATH || "./data/fluxel.sqlite");
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL COLLATE NOCASE UNIQUE,
  email TEXT NOT NULL COLLATE NOCASE UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS profiles (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL,
  avatar_json TEXT NOT NULL DEFAULT '{}',
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS player_saves (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  save_key TEXT NOT NULL,
  save_json TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY(user_id, save_key)
);
CREATE TABLE IF NOT EXISTS game_servers (
  id TEXT PRIMARY KEY,
  game_id TEXT NOT NULL,
  room_code TEXT NOT NULL UNIQUE,
  host_user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  player_count INTEGER NOT NULL DEFAULT 1,
  max_players INTEGER NOT NULL DEFAULT 12,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

const id = () => require("crypto").randomUUID();
const usernameOk = s => typeof s === "string" && /^[A-Za-z0-9_]{3,20}$/.test(s);
const emailOk = s => typeof s === "string" && s.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
function auth(req, res, next) {
  const header = req.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try {
    req.user = jwt.verify(token, JWT_SECRET, { issuer: "fluxel-api", audience: "fluxel-client" });
    next();
  } catch {
    return res.status(401).json({ error: "Sign in to continue." });
  }
}
function issueToken(user) {
  return jwt.sign({ sub: user.id, username: user.username }, JWT_SECRET, {
    expiresIn: "7d", issuer: "fluxel-api", audience: "fluxel-client"
  });
}
function publicUser(user) {
  const profile = db.prepare("SELECT display_name, avatar_json, updated_at FROM profiles WHERE user_id = ?").get(user.id);
  return {
    id: user.id, username: user.username, email: user.email, createdAt: user.created_at,
    profile: profile ? { displayName: profile.display_name, avatar: JSON.parse(profile.avatar_json), updatedAt: profile.updated_at } : null
  };
}

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "Fluxel API", database: "connected" }));

app.post("/api/auth/register", async (req, res) => {
  const { username, email, password } = req.body || {};
  if (!usernameOk(username)) return res.status(400).json({ error: "Username must be 3–20 characters using letters, numbers, or underscores." });
  if (!emailOk(email)) return res.status(400).json({ error: "Enter a valid email address." });
  if (typeof password !== "string" || password.length < 10 || password.length > 128) return res.status(400).json({ error: "Password must be 10–128 characters." });
  const normalizedEmail = email.trim().toLowerCase();
  const normalizedUsername = username.trim();
  if (db.prepare("SELECT 1 FROM users WHERE username = ? COLLATE NOCASE OR email = ? COLLATE NOCASE").get(normalizedUsername, normalizedEmail)) {
    return res.status(409).json({ error: "That username or email is already registered." });
  }
  const user = { id: id(), username: normalizedUsername, email: normalizedEmail };
  const hash = await bcrypt.hash(password, 12);
  const tx = db.transaction(() => {
    db.prepare("INSERT INTO users (id, username, email, password_hash) VALUES (?, ?, ?, ?)").run(user.id, user.username, user.email, hash);
    db.prepare("INSERT INTO profiles (user_id, display_name, avatar_json) VALUES (?, ?, '{}')").run(user.id, user.username);
  });
  try { tx(); } catch (e) { return res.status(409).json({ error: "Could not create account. Check that the username and email are unique." }); }
  const saved = db.prepare("SELECT id, username, email, created_at FROM users WHERE id = ?").get(user.id);
  res.status(201).json({ token: issueToken(saved), user: publicUser(saved) });
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body || {};
  if (!emailOk(email) || typeof password !== "string") return res.status(400).json({ error: "Enter your email and password." });
  const user = db.prepare("SELECT * FROM users WHERE email = ? COLLATE NOCASE").get(email.trim());
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Email or password is incorrect." });
  res.json({ token: issueToken(user), user: publicUser(user) });
});

app.get("/api/me", auth, (req, res) => {
  const user = db.prepare("SELECT id, username, email, created_at FROM users WHERE id = ?").get(req.user.sub);
  if (!user) return res.status(404).json({ error: "Account not found." });
  res.json({ user: publicUser(user) });
});

app.patch("/api/me/profile", auth, (req, res) => {
  const { displayName, avatar } = req.body || {};
  if (displayName !== undefined && (typeof displayName !== "string" || displayName.trim().length < 1 || displayName.trim().length > 32)) {
    return res.status(400).json({ error: "Display name must be 1–32 characters." });
  }
  if (avatar !== undefined && (avatar === null || typeof avatar !== "object" || Array.isArray(avatar) || JSON.stringify(avatar).length > 20000)) {
    return res.status(400).json({ error: "Avatar data must be a JSON object under 20 KB." });
  }
  const current = db.prepare("SELECT display_name, avatar_json FROM profiles WHERE user_id = ?").get(req.user.sub);
  if (!current) return res.status(404).json({ error: "Profile not found." });
  db.prepare("UPDATE profiles SET display_name = ?, avatar_json = ?, updated_at = datetime('now') WHERE user_id = ?")
    .run(displayName === undefined ? current.display_name : displayName.trim(),
         avatar === undefined ? current.avatar_json : JSON.stringify(avatar), req.user.sub);
  res.json({ profile: db.prepare("SELECT display_name AS displayName, avatar_json AS avatar, updated_at AS updatedAt FROM profiles WHERE user_id = ?").get(req.user.sub) });
});

app.put("/api/saves/:key", auth, (req, res) => {
  const key = req.params.key;
  if (!/^[A-Za-z0-9._-]{1,64}$/.test(key)) return res.status(400).json({ error: "Save key must be 1–64 letters, numbers, dots, underscores, or hyphens." });
  const data = req.body && req.body.data;
  if (data === undefined || JSON.stringify(data).length > 50000) return res.status(400).json({ error: "Include data smaller than 50 KB." });
  db.prepare(`INSERT INTO player_saves(user_id, save_key, save_json, updated_at) VALUES(?, ?, ?, datetime('now'))
    ON CONFLICT(user_id, save_key) DO UPDATE SET save_json=excluded.save_json, updated_at=datetime('now')`)
    .run(req.user.sub, key, JSON.stringify(data));
  res.json({ ok: true, key, updatedAt: db.prepare("SELECT updated_at FROM player_saves WHERE user_id = ? AND save_key = ?").get(req.user.sub, key).updated_at });
});
app.get("/api/saves", auth, (_req, res) => {
  const rows = db.prepare("SELECT save_key, save_json, updated_at FROM player_saves WHERE user_id = ? ORDER BY save_key").all(_req.user.sub);
  res.json({ saves: rows.map(r => ({ key: r.save_key, data: JSON.parse(r.save_json), updatedAt: r.updated_at })) });
});
app.get("/api/saves/:key", auth, (req, res) => {
  const row = db.prepare("SELECT save_json, updated_at FROM player_saves WHERE user_id = ? AND save_key = ?").get(req.user.sub, req.params.key);
  if (!row) return res.status(404).json({ error: "Save not found." });
  res.json({ key: req.params.key, data: JSON.parse(row.save_json), updatedAt: row.updated_at });
});

app.get("/api/servers", (_req, res) => {
  const rows = db.prepare("SELECT id, game_id AS gameId, room_code AS roomCode, player_count AS playerCount, max_players AS maxPlayers, status, created_at AS createdAt FROM game_servers WHERE status = 'open' ORDER BY created_at DESC LIMIT 100").all();
  res.json({ servers: rows });
});
app.post("/api/servers", auth, (req, res) => {
  const { gameId, maxPlayers } = req.body || {};
  if (typeof gameId !== "string" || !/^[A-Za-z0-9._-]{1,80}$/.test(gameId)) return res.status(400).json({ error: "Invalid gameId." });
  const cap = Number(maxPlayers || 12);
  if (!Number.isInteger(cap) || cap < 1 || cap > 100) return res.status(400).json({ error: "maxPlayers must be between 1 and 100." });
  let roomCode;
  do { roomCode = Math.random().toString(36).slice(2, 8).toUpperCase(); } while (db.prepare("SELECT 1 FROM game_servers WHERE room_code = ?").get(roomCode));
  const serverId = id();
  db.prepare("INSERT INTO game_servers(id, game_id, room_code, host_user_id, player_count, max_players) VALUES(?, ?, ?, ?, 1, ?)")
    .run(serverId, gameId, roomCode, req.user.sub, cap);
  res.status(201).json({ server: { id: serverId, gameId, roomCode, playerCount: 1, maxPlayers: cap, status: "open" } });
});
app.post("/api/servers/join", auth, (req, res) => {
  const code = String((req.body || {}).roomCode || "").trim().toUpperCase();
  const server = db.prepare("SELECT * FROM game_servers WHERE room_code = ? AND status = 'open'").get(code);
  if (!server) return res.status(404).json({ error: "Room code not found." });
  if (server.player_count >= server.max_players) return res.status(409).json({ error: "That server is full." });
  db.prepare("UPDATE game_servers SET player_count = player_count + 1 WHERE id = ?").run(server.id);
  res.json({ server: { id: server.id, gameId: server.game_id, roomCode: server.room_code, playerCount: server.player_count + 1, maxPlayers: server.max_players, status: server.status } });
});

app.use((err, _req, res, _next) => {
  if (err && err.message === "Origin not allowed by CORS") return res.status(403).json({ error: "This website origin is not allowed." });
  console.error(err);
  res.status(500).json({ error: "Unexpected server error." });
});
app.listen(PORT, "0.0.0.0", () => console.log(`Fluxel API listening on port ${PORT}`));
